<?php

namespace App\Filament\Resources\InvoiceResource\RelationManagers;

use Filament\Facades\Filament;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class PaymentsRelationManager extends RelationManager
{
    protected static string $relationship = 'payments';
    protected static ?string $title = 'الدفعات';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\DatePicker::make('paid_at')
                ->label('تاريخ الدفع')
                ->default(now())
                ->required(),

            Forms\Components\TextInput::make('amount')
                ->label('المبلغ')
                ->numeric()
                ->required(),

            Forms\Components\Select::make('method')
                ->label('طريقة الدفع')
                ->options([
                    'cash' => 'Cash',
                    'card' => 'Card',
                    'bank' => 'Bank Transfer',
                    'wallet' => 'Wallet',
                ])
                ->required()
                ->default('cash'),

            Forms\Components\TextInput::make('reference')
                ->label('Reference')
                ->maxLength(255),

            Forms\Components\Textarea::make('notes')
                ->label('ملاحظات')
                ->rows(3),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->heading('الدفعات')
            ->columns([
                Tables\Columns\TextColumn::make('paid_at')->label('التاريخ')->date()->sortable(),
                Tables\Columns\TextColumn::make('amount')->label('المبلغ')->money('USD')->sortable(),
                Tables\Columns\TextColumn::make('method')->label('الطريقة')->sortable(),
                Tables\Columns\TextColumn::make('reference')->label('المرجع')->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('created_at')->label('أضيفت في')->dateTime()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->label('إضافة دفعة')
                    ->mutateFormDataUsing(function (array $data): array {
                        $data['tenant_id'] = Filament::auth()->user()->tenant_id;
                        return $data;
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->mutateFormDataUsing(function (array $data): array {
                        $data['tenant_id'] = Filament::auth()->user()->tenant_id;
                        return $data;
                    }),
                Tables\Actions\DeleteAction::make(),
            ]);
    }
}
