<?php
    $tenant = \Filament\Facades\Filament::getTenant();
    $css = \App\Support\Branding\BrandCss::forTenant($tenant);
?>

<?php echo $css; ?>

<?php /**PATH C:\Users\Amro Shahrouri\Desktop\laravel\travel-saas\resources\views/filament/hooks/tenant-branding-css.blade.php ENDPATH**/ ?>