<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Amro Shahrouri\Desktop\laravel\travel-saas\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>