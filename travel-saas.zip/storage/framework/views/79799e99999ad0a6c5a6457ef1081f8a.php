<style>
    /* اجعل الشعار دائري + ترتيب الاسم جنب الشعار */
    .fi-topbar .fi-logo,
    .fi-sidebar-header .fi-logo {
        gap: 0.5rem !important;
    }

    .fi-topbar .fi-logo img,
    .fi-sidebar-header .fi-logo img {
        border-radius: 9999px !important;
        object-fit: cover;
    }
</style>
<?php /**PATH C:\Users\Amro Shahrouri\Desktop\laravel\travel-saas\resources\views/filament/hooks/brand-round-logo.blade.php ENDPATH**/ ?>